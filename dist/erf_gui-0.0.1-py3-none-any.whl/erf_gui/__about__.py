# SPDX-FileCopyrightText: 2024-present John Fiocca <void@some.where>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
