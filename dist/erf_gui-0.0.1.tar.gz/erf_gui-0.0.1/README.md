# ERF GUI

[![PyPI - Version](https://img.shields.io/pypi/v/erf-gui.svg)](https://pypi.org/project/erf-gui)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/erf-gui.svg)](https://pypi.org/project/erf-gui)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install erf-gui
```

## License

`erf-gui` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
